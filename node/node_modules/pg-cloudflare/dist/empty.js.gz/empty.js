// This is an empty module that is served up when outside of a workerd environment
// See the `exports` field in package.json
export default {};
//# sourceMappingURL=empty.js.map